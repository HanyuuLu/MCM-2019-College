class MonthlyRec:
    def __init__(self):
        self.fileName = "None"
        self.data = []


class UserRecord:
    def __init__(self):
        self.uuid = None
        self.record = list()
